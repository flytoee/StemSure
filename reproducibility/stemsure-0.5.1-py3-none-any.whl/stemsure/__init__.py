"""StemSure measurement package. Field references are read by separate evaluation tools."""

__version__ = "0.2.0"
