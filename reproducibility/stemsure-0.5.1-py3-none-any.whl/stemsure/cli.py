"""Command-line entry point for independent measurement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .pipeline import measure


def main() -> None:
    parser = argparse.ArgumentParser(prog="stemsure", description="Measure tree candidates in a LAS/LAZ plot")
    parser.add_argument("--input", required=True, help="LAS or LAZ point cloud")
    parser.add_argument("--output", required=True, help="New result directory")
    parser.add_argument("--normalized", action="store_true", help="Use input Z as height above ground")
    parser.add_argument("--ground-class", default="2",
                        help="Ground LAS class (default: 2), or all for a class-free fifth-percentile surface")
    parser.add_argument("--stem-class", default="1",
                        help="Stem/vegetation LAS class (default: 1; use all if needed)")
    parser.add_argument("--seed", type=int, default=20260927)
    parser.add_argument("--trials", type=int, default=20000,
                        help="Randomized Hough trials per candidate and height")
    args = parser.parse_args()
    if args.stem_class == "all":
        stem_class = None
    else:
        try:
            stem_class = int(args.stem_class)
        except ValueError:
            parser.error("--stem-class must be an integer or all")
    if args.ground_class == "all":
        ground_class = None
    else:
        try:
            ground_class = int(args.ground_class)
        except ValueError:
            parser.error("--ground-class must be an integer or all")
    try:
        report = measure(Path(args.input), Path(args.output), ground_class=ground_class,
                         stem_class=stem_class, normalized=args.normalized,
                         seed=args.seed, trials=args.trials)
    except (OSError, ValueError) as exc:
        parser.exit(2, f"StemSure failed: {exc}\n")
    print(json.dumps({"output": args.output, "candidate_count": report["candidate_count"],
                      "decision_counts": report["decision_counts"],
                      "runtime_seconds": report["runtime_seconds"]}, ensure_ascii=False))
